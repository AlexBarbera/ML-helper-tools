from .ImageLosses import WassersteinLoss, PerceptualLoss, TotalVariationLoss
from .ClassificationLosses import DeepEnergyLoss
